# خدملك 0.5 — Firebase Connected

هذا الإصدار مرتبط بمشروع Firebase الموجود في `app/google-services.json`.
اسم الحزمة: `com.khedmak.app`

## ما يعمل
- تسجيل حساب زبون أو مقدم خدمة عبر Firebase Authentication.
- حفظ ملفات المستخدمين في Firestore.
- الزبون ينشئ طلب خدمة مع المنطقة والهاتف والموقع عند السماح بالموقع.
- الطلب يظهر لمقدمي الخدمة عبر Firestore listener بشكل شبه فوري.
- مقدم الخدمة يقبل الطلب، ويتم حفظ providerId والحالة accepted.
- الزبون يرى طلباته وحالتها مباشرة.
- فصل واجهة الزبون عن مقدم الخدمة حسب الدور.
- Firestore Security Rules مرفقة في `firestore.rules`.

## قبل التجربة
من Firebase Console فعّل:
1. Authentication > Sign-in method > Email/Password.
2. Firestore Database > Create database.
3. انسخ محتوى `firestore.rules` إلى Firestore Rules ثم Publish.

## التشغيل
افتح المشروع في Android Studio ثم Gradle Sync ثم Run.

## ملاحظات
هذا الإصدار لا يحتوي بعد على: الدفع، الدردشة، FCM push notifications، لوحة تحكم ويب، خرائط Google داخل التطبيق، ونظام عمولة آمن من جهة الخادم. يمكن إضافتها في الإصدار التالي.
