package com.khedmak.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class KhedmakRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun register(name:String, phone:String, email:String, password:String, role:String, onResult:(Boolean,String)->Unit) {
        if(name.isBlank() || phone.isBlank() || email.isBlank() || password.length < 6) { onResult(false,"أكمل البيانات وكلمة المرور يجب أن تكون 6 أحرف على الأقل"); return }
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                val uid=result.user!!.uid
                db.collection("users").document(uid).set(mapOf("name" to name.trim(), "phone" to phone.trim(), "email" to email.trim(), "role" to role, "createdAt" to System.currentTimeMillis()))
                    .addOnSuccessListener { onResult(true, "تم إنشاء الحساب") }
                    .addOnFailureListener { onResult(false, it.message ?: "تعذر حفظ الحساب") }
            }.addOnFailureListener { onResult(false, it.message ?: "تعذر إنشاء الحساب") }
    }

    fun login(email:String,password:String,onResult:(Boolean,String)->Unit) {
        auth.signInWithEmailAndPassword(email.trim(),password).addOnSuccessListener { onResult(true,"تم تسجيل الدخول") }
            .addOnFailureListener { onResult(false,it.message ?: "بيانات الدخول غير صحيحة") }
    }

    fun saveProfile(name:String, phone:String, role:String, onResult:(Boolean,String)->Unit) {
        val uid=currentUid() ?: return onResult(false,"سجل الدخول أولاً")
        if(name.isBlank() || phone.isBlank()) { onResult(false,"يرجى تعبئة الاسم ورقم الهاتف"); return }
        db.collection("users").document(uid).set(mapOf(
            "name" to name.trim(),
            "phone" to phone.trim(),
            "email" to (auth.currentUser?.email ?: ""),
            "role" to role,
            "createdAt" to System.currentTimeMillis()
        )).addOnSuccessListener { onResult(true,"تم حفظ الحساب") }
          .addOnFailureListener { onResult(false,it.message ?: "تعذر حفظ الحساب") }
    }

    fun logout() = auth.signOut()
    fun currentUid(): String? = auth.currentUser?.uid

    fun getMyRole(onResult:(String?)->Unit) {
        val uid = currentUid() ?: return onResult(null)
        db.collection("users").document(uid).get()
            .addOnSuccessListener { onResult(it.getString("role")) }
            .addOnFailureListener { onResult(null) }
    }

    fun createRequest(service:String, description:String, area:String, phone:String, lat:Double?, lng:Double?, onResult:(Boolean,String)->Unit) {
        val uid=auth.currentUser?.uid
        if(uid==null){ onResult(false,"سجل الدخول أولاً"); return }
        if(description.isBlank() || area.isBlank() || phone.isBlank()){ onResult(false,"يرجى تعبئة وصف المشكلة والمنطقة ورقم الهاتف"); return }
        val data=hashMapOf<String,Any>("customerId" to uid,"service" to service,"description" to description.trim(),"area" to area.trim(),"phone" to phone.trim(),"status" to "pending","createdAt" to System.currentTimeMillis())
        if(lat!=null && lng!=null){data["latitude"]=lat; data["longitude"]=lng}
        db.collection("requests").add(data).addOnSuccessListener { onResult(true,"تم إرسال الطلب لمقدمي الخدمة") }
            .addOnFailureListener { onResult(false,it.message ?: "تعذر إرسال الطلب") }
    }

    fun listenPendingRequests(onResult:(List<Map<String,Any>>)->Unit, onError:(String)->Unit): ListenerRegistration {
        return db.collection("requests").whereEqualTo("status","pending").limit(50)
            .addSnapshotListener { snap, e ->
                if(e != null) { onError(e.message ?: "تعذر تحميل الطلبات"); return@addSnapshotListener }
                onResult((snap?.documents?.map { d -> d.data.orEmpty().plus("id" to d.id) } ?: emptyList()).sortedByDescending { (it["createdAt"] as? Number)?.toLong() ?: 0L })
            }
    }

    fun listenMyRequests(onResult:(List<Map<String,Any>>)->Unit, onError:(String)->Unit): ListenerRegistration {
        val uid=currentUid() ?: throw IllegalStateException("not logged in")
        return db.collection("requests").whereEqualTo("customerId",uid).limit(50)
            .addSnapshotListener { snap,e ->
                if(e != null) { onError(e.message ?: "تعذر تحميل طلباتك"); return@addSnapshotListener }
                onResult((snap?.documents?.map { d -> d.data.orEmpty().plus("id" to d.id) } ?: emptyList()).sortedByDescending { (it["createdAt"] as? Number)?.toLong() ?: 0L })
            }
    }

    fun acceptRequest(id:String,onResult:(Boolean,String)->Unit) {
        val uid=auth.currentUser?.uid ?: return onResult(false,"سجل الدخول أولاً")
        db.collection("requests").document(id).get().addOnSuccessListener { doc ->
            if(!doc.exists() || doc.getString("status") != "pending") { onResult(false,"هذا الطلب لم يعد متاحًا"); return@addOnSuccessListener }
            db.collection("requests").document(id).update(mapOf("status" to "accepted","providerId" to uid,"acceptedAt" to System.currentTimeMillis()))
                .addOnSuccessListener{onResult(true,"تم قبول الطلب")}.addOnFailureListener{onResult(false,it.message ?: "تعذر قبول الطلب")}
        }.addOnFailureListener { onResult(false,it.message ?: "تعذر التحقق من الطلب") }
    }
}
