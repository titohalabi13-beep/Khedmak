package com.khedmak.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.ListenerRegistration
import com.khedmak.app.data.KhedmakRepository

class MainActivity : Activity() {
    private val repo=KhedmakRepository()
    private val location by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var listener: ListenerRegistration? = null
    private val services=listOf("🔧 كهربائي","🚰 سباك","❄️ تكييف وتبريد","🛠️ تصليح أجهزة","🎨 دهان","🧹 تنظيف","🪚 نجار","🚗 ميكانيكي","📱 صيانة موبايلات","➕ خدمات أخرى")

    override fun onCreate(b:Bundle?){super.onCreate(b); showAuth()}
    override fun onDestroy(){listener?.remove();super.onDestroy()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun base():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(20));gravity=Gravity.CENTER_HORIZONTAL}
    private fun title(t:String)=TextView(this).apply{text=t;textSize=26f;gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(12))}
    private fun field(hint:String,minLines:Int=1)=EditText(this).apply{
        this.hint=hint;textSize=16f;setPadding(dp(12),dp(8),dp(12),dp(8));if(minLines>1)this.minLines=minLines
        layoutParams=LinearLayout.LayoutParams(-1,if(minLines>1)dp(110) else dp(58)).apply{setMargins(0,dp(5),0,dp(5))}
    }
    private fun button(text:String,action:()->Unit)=Button(this).apply{
        setText(text);textSize=16f;minHeight=dp(58);minimumHeight=dp(58);isAllCaps=false;setPadding(dp(12),dp(8),dp(12),dp(8))
        layoutParams=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(0,dp(5),0,dp(5))};setOnClickListener{action()}
    }
    private fun showRoot(view:LinearLayout){ScrollView(this).also{it.isFillViewport=true;it.addView(view,ViewGroup.LayoutParams(-1,-1));setContentView(it)}}

    private fun showAuth(){
        listener?.remove();val r=base();r.addView(title("خدملك"));val email=field("البريد الإلكتروني");r.addView(email)
        val pass=field("كلمة المرور");pass.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;r.addView(pass)
        r.addView(button("تسجيل الدخول"){repo.login(email.text.toString(),pass.text.toString()){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()}})
        r.addView(button("إنشاء حساب جديد"){showRegister()});showRoot(r)
    }
    private fun showRegister(){
        val r=base();r.addView(title("إنشاء حساب"));val name=field("الاسم");r.addView(name);val phone=field("رقم الهاتف");r.addView(phone);val email=field("البريد الإلكتروني");r.addView(email)
        val pass=field("كلمة المرور (6 أحرف على الأقل)");pass.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;r.addView(pass)
        val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("زبون","مقدم خدمة"));r.addView(role)
        r.addView(button("إنشاء الحساب"){repo.register(name.text.toString(),phone.text.toString(),email.text.toString(),pass.text.toString(),if(role.selectedItemPosition==0)"customer" else "provider"){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()}})
        r.addView(button("رجوع"){showAuth()});showRoot(r)
    }
    private fun routeHome(){repo.getMyRole{role->when(role){"provider"->showProviderHome();"customer"->showCustomerHome();else->showCompleteProfile()}}}
    private fun showCompleteProfile(){
        val r=base();r.addView(title("إكمال الحساب"));r.addView(TextView(this).apply{text="تم تسجيل الدخول بنجاح. أكمل بيانات حسابك.";textSize=17f})
        val name=field("الاسم");r.addView(name);val phone=field("رقم الهاتف");r.addView(phone);val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("زبون","مقدم خدمة"));r.addView(role)
        r.addView(button("حفظ والمتابعة"){repo.saveProfile(name.text.toString(),phone.text.toString(),if(role.selectedItemPosition==0)"customer" else "provider"){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()}})
        r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});showRoot(r)
    }

    private fun showCustomerHome(){
        listener?.remove();val r=base();r.addView(title("خدملك - خدمات منزلية"));services.forEach{s->r.addView(button(s){showRequest(s)})}
        r.addView(button("📋 طلباتي"){showMyRequests()});r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});showRoot(r)
    }
    private fun showRequest(service:String){
        val r=base();r.addView(title("طلب: $service"));val desc=field("صف المشكلة بالتفصيل",4);r.addView(desc);val area=field("المنطقة");r.addView(area);val phone=field("رقم الهاتف");r.addView(phone)
        r.addView(button("📍 إرسال الطلب مع الموقع"){submit(service,desc.text.toString(),area.text.toString(),phone.text.toString())});r.addView(button("رجوع"){showCustomerHome()});showRoot(r)
    }
    private fun submit(service:String,d:String,a:String,p:String){
        fun send(lat:Double?,lng:Double?){repo.createRequest(service,d,a,p,lat,lng){ok,msg->AlertDialog.Builder(this).setMessage(msg).setPositiveButton("حسنًا"){_,_->if(ok)showCustomerHome()}.show()}}
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){location.lastLocation.addOnSuccessListener{send(it?.latitude,it?.longitude)}}
        else {requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),9);send(null,null)}
    }

    private fun showMyRequests(){
        val r=base();r.addView(title("طلباتي"));val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list);listener?.remove()
        listener=repo.listenMyRequests({items->list.removeAllViews();if(items.isEmpty())list.addView(TextView(this).apply{text="لا توجد طلبات بعد";textSize=18f})
            items.forEach{m->
                val status=(m["status"] as? String ?: ""
                val card=Button(this);card.text="${m["service"]}\n${m["area"]}\nالحالة: ${statusText(status)}"
                card.setOnClickListener{showCustomerRequestDetails(m)};list.addView(card)
            }
        }, {e->Toast.makeText(this,e,Toast.LENGTH_SHORT).show()})
        r.addView(button("رجوع"){listener?.remove();showCustomerHome()});showRoot(r)
    }
    private fun showCustomerRequestDetails(m:Map<String,Any>){
        val id=m["id"]?.toString() ?: return;val status=(m["status"] as? String ?: "";val r=base();r.addView(title("تفاصيل الطلب"))
        r.addView(TextView(this).apply{text="الخدمة: ${m["service"]}\nالمنطقة: ${m["area"]}\nالوصف: ${m["description"]}\nالحالة: ${statusText(status)}";textSize=17f})
        val providerName=m["providerName"]?.toString().orEmpty();val providerPhone=m["providerPhone"]?.toString().orEmpty()
        if(providerName.isNotBlank())r.addView(TextView(this).apply{text="\nمقدم الخدمة: $providerName\nالهاتف: $providerPhone";textSize=18f})
        val price=(m["price"] as? Number)?.toDouble()
        if(price!=null)r.addView(TextView(this).apply{text="\nالسعر المقترح: ${formatPrice(price)}";textSize=20f})
        if(providerPhone.isNotBlank())r.addView(button("📞 اتصال بمقدم الخدمة"){call(providerPhone)})
        if(status=="price_sent"){
            r.addView(button("✅ أوافق على السعر"){repo.customerPriceDecision(id,true){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)showMyRequests()}})
            r.addView(button("❌ أرفض السعر"){repo.customerPriceDecision(id,false){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)showMyRequests()}})
        }
        if(status=="completed" && m["providerId"]?.toString().orEmpty().isNotBlank()){
            r.addView(button("⭐ تقييم مقدم الخدمة"){showRatingDialog(id,m["providerId"].toString())})
        }
        r.addView(button("رجوع"){showMyRequests()});showRoot(r)
    }
    private fun showRatingDialog(requestId:String,providerId:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(10),dp(20),0)}
        val rating=RatingBar(this);rating.numStars=5;rating.stepSize=1f;rating.rating=5f;box.addView(rating)
        val comment=field("ملاحظة (اختياري)",3);box.addView(comment)
        AlertDialog.Builder(this).setTitle("تقييم مقدم الخدمة").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("إرسال"){_,_->repo.rateProvider(requestId,providerId,rating.rating.toInt(),comment.text.toString()){_,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}}.show()
    }
    private fun statusText(s:String)=when(s){"pending"->"بانتظار مقدم خدمة";"accepted"->"تم قبول الطلب - بانتظار السعر";"price_sent"->"تم إرسال السعر - بانتظار موافقتك";"price_rejected"->"تم رفض السعر - بانتظار سعر جديد";"agreed"->"تم الاتفاق على السعر";"completed"->"مكتمل - يمكنك التقييم";else->s}
    private fun formatPrice(v:Double)="%.2f $".format(java.util.Locale.US,v)
    private fun call(phone:String){try{startActivity(Intent(Intent.ACTION_DIAL).apply{data=android.net.Uri.parse("tel:${phone.trim()}")})}catch(_:Exception){Toast.makeText(this,"تعذر فتح الاتصال",Toast.LENGTH_SHORT).show()}}

    private fun showProviderHome(){
        listener?.remove();val r=base();r.addView(title("لوحة مقدم الخدمة"));r.addView(button("🔔 الطلبات الجديدة"){showProviderRequests()});r.addView(button("📋 طلباتي المقبولة"){showProviderAcceptedRequests()});r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});showRoot(r)
    }
    private fun showProviderRequests(){
        val r=base();r.addView(title("الطلبات الجديدة"));val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list);listener?.remove()
        listener=repo.listenPendingRequests({items->list.removeAllViews();if(items.isEmpty())list.addView(TextView(this).apply{text="لا توجد طلبات جديدة";textSize=18f})
            items.forEach{m->val b=Button(this);b.text="${m["service"]}\n${m["area"]}\n${m["description"]}";b.setOnClickListener{AlertDialog.Builder(this).setTitle("قبول الطلب؟").setMessage("رقم العميل: ${m["phone"]}").setNegativeButton("إلغاء",null).setPositiveButton("قبول"){_,_->repo.acceptRequest(m["id"].toString()){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}}.show()};list.addView(b)}} ,{e->Toast.makeText(this,e,Toast.LENGTH_SHORT).show()})
        r.addView(button("رجوع"){listener?.remove();showProviderHome()});showRoot(r)
    }
    private fun showProviderAcceptedRequests(){
        val r=base();r.addView(title("طلباتي المقبولة"));val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list);listener?.remove()
        listener=repo.listenProviderRequests({items->list.removeAllViews();if(items.isEmpty())list.addView(TextView(this).apply{text="لا توجد طلبات مقبولة بعد";textSize=18f})
            items.forEach{m->val b=Button(this);b.text="${m["service"]}\n${m["area"]}\nالحالة: ${statusText((m["status"] as? String ?: "")}";b.setOnClickListener{showProviderRequestDetails(m)};list.addView(b)}} ,{e->Toast.makeText(this,e,Toast.LENGTH_SHORT).show()})
        r.addView(button("رجوع"){listener?.remove();showProviderHome()});showRoot(r)
    }
    private fun showProviderRequestDetails(m:Map<String,Any>){
        val id=m["id"]?.toString() ?: return;val status=(m["status"] as? String ?: "";val r=base();r.addView(title("تفاصيل الطلب"))
        r.addView(TextView(this).apply{text="الخدمة: ${m["service"]}\nالمنطقة: ${m["area"]}\nالوصف: ${m["description"]}\nرقم الزبون: ${m["phone"]}\nالحالة: ${statusText(status)}";textSize=17f})
        if(status=="accepted" || status=="price_rejected"){
            val price=field("السعر بالدولار، مثال: 25");price.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;r.addView(price)
            r.addView(button("💰 إرسال السعر"){repo.sendPrice(id,price.text.toString()){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)showProviderAcceptedRequests()}})
        }
        if(status=="agreed")r.addView(button("✅ تم إنجاز الخدمة"){repo.completeRequest(id){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)showProviderAcceptedRequests()}})
        r.addView(button("📞 اتصال بالزبون"){call(m["phone"]?.toString().orEmpty())})
        r.addView(button("رجوع"){showProviderAcceptedRequests()});showRoot(r)
    }
}
