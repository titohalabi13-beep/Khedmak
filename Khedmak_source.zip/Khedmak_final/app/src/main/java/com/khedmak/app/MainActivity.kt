package com.khedmak.app

import android.Manifest
import android.app.*
import android.os.Bundle
import android.content.pm.PackageManager
import android.view.Gravity
import android.widget.*
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.ListenerRegistration
import com.khedmak.app.data.KhedmakRepository

class MainActivity : Activity() {
    private val repo=KhedmakRepository()
    private val location by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var listener: ListenerRegistration? = null
    private val services=listOf("🔧 كهربائي","🚰 سباك","❄️ تكييف وتبريد","🛠️ تصليح أجهزة","🎨 دهان","🧹 تنظيف","🪚 نجار","🚗 ميكانيكي","📱 صيانة موبايلات","➕ خدمات أخرى")

    override fun onCreate(b:Bundle?){super.onCreate(b); showAuth()}
    override fun onDestroy(){ listener?.remove(); super.onDestroy() }
    private fun base():LinearLayout{ val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(28,24,28,20);return r }
    private fun title(t:String):TextView{val v=TextView(this);v.text=t;v.textSize=28f;v.gravity=Gravity.CENTER;return v}
    private fun button(text:String, action:()->Unit):Button=Button(this).apply{setText(text);setOnClickListener{action()}}

    private fun showAuth(){
        listener?.remove(); val r=base();r.addView(title("خدملك"),LinearLayout.LayoutParams(-1,70))
        val email=EditText(this);email.hint="البريد الإلكتروني";r.addView(email)
        val pass=EditText(this);pass.hint="كلمة المرور";pass.inputType=129;r.addView(pass)
        r.addView(button("تسجيل الدخول"){repo.login(email.text.toString(),pass.text.toString()){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()}})
        r.addView(button("إنشاء حساب جديد"){showRegister()});setContentView(r)
    }

    private fun showRegister(){
        val r=base();r.addView(title("إنشاء حساب"));
        val name=EditText(this);name.hint="الاسم";r.addView(name)
        val phone=EditText(this);phone.hint="رقم الهاتف";r.addView(phone)
        val email=EditText(this);email.hint="البريد الإلكتروني";r.addView(email)
        val pass=EditText(this);pass.hint="كلمة المرور (6 أحرف على الأقل)";pass.inputType=129;r.addView(pass)
        val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("زبون","مقدم خدمة"));r.addView(role)
        r.addView(button("إنشاء الحساب"){repo.register(name.text.toString(),phone.text.toString(),email.text.toString(),pass.text.toString(),if(role.selectedItemPosition==0)"customer" else "provider"){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()}})
        r.addView(button("رجوع"){showAuth()});setContentView(r)
    }

    private fun routeHome(){
        repo.getMyRole{role->
            when(role){
                "provider" -> showProviderHome()
                "customer" -> showCustomerHome()
                else -> showCompleteProfile()
            }
        }
    }

    private fun showCompleteProfile(){
        val r=base();r.addView(title("إكمال الحساب"));
        r.addView(TextView(this).apply{text="تم تسجيل الدخول بنجاح. أكمل بيانات حسابك.";textSize=17f})
        val name=EditText(this);name.hint="الاسم";r.addView(name)
        val phone=EditText(this);phone.hint="رقم الهاتف";r.addView(phone)
        val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("زبون","مقدم خدمة"));r.addView(role)
        r.addView(button("حفظ والمتابعة"){
            repo.saveProfile(name.text.toString(),phone.text.toString(),if(role.selectedItemPosition==0)"customer" else "provider"){ok,msg->
                Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();if(ok)routeHome()
            }
        })
        r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});setContentView(r)
    }

    private fun showCustomerHome(){
        listener?.remove();val r=base();r.addView(title("خدملك - خدمات منزلية"));
        services.forEach{s->r.addView(button(s){showRequest(s)},LinearLayout.LayoutParams(-1,58))}
        r.addView(button("📋 طلباتي"){showMyRequests()});r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});setContentView(r)
    }

    private fun showRequest(service:String){
        val r=base();r.addView(title("طلب: $service"));
        val desc=EditText(this);desc.hint="صف المشكلة بالتفصيل";desc.minLines=4;r.addView(desc)
        val area=EditText(this);area.hint="المنطقة";r.addView(area)
        val phone=EditText(this);phone.hint="رقم الهاتف";r.addView(phone)
        r.addView(button("📍 إرسال الطلب مع الموقع"){submit(service,desc.text.toString(),area.text.toString(),phone.text.toString())})
        r.addView(button("رجوع"){showCustomerHome()});setContentView(r)
    }

    private fun submit(service:String,d:String,a:String,p:String){
        fun send(lat:Double?,lng:Double?){repo.createRequest(service,d,a,p,lat,lng){ok,msg->AlertDialog.Builder(this).setMessage(msg).setPositiveButton("حسنًا"){_,_->if(ok)showCustomerHome()}.show()}}
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){location.lastLocation.addOnSuccessListener{send(it?.latitude,it?.longitude)}}
        else {requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),9);send(null,null)}
    }

    private fun showMyRequests(){
        val r=base();r.addView(title("طلباتي"));val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list)
        listener?.remove();listener=repo.listenMyRequests({items->list.removeAllViews();if(items.isEmpty()){list.addView(TextView(this).apply{text="لا توجد طلبات بعد";textSize=18f})};items.forEach{m->
            val status=(m["status"] as? String) ?: ""
            val b=Button(this);b.text="${m["service"]}\n${m["area"]}\nالحالة: ${statusText(status)}";list.addView(b)
        }},{e->Toast.makeText(this,e,Toast.LENGTH_SHORT).show()})
        r.addView(button("رجوع"){listener?.remove();showCustomerHome()});setContentView(r)
    }

    private fun statusText(s:String)=when(s){"pending"->"بانتظار مقدم خدمة";"accepted"->"تم قبول الطلب";"completed"->"مكتمل";else->s}

    private fun showProviderHome(){
        listener?.remove();val r=base();r.addView(title("لوحة مقدم الخدمة"));
        r.addView(button("🔔 الطلبات الجديدة"){showProviderRequests()})
        r.addView(button("تسجيل الخروج"){repo.logout();showAuth()});setContentView(r)
    }

    private fun showProviderRequests(){
        val r=base();r.addView(title("الطلبات الجديدة"));val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list)
        listener?.remove();listener=repo.listenPendingRequests({items->list.removeAllViews();if(items.isEmpty())list.addView(TextView(this).apply{text="لا توجد طلبات جديدة";textSize=18f});items.forEach{m->
            val b=Button(this);b.text="${m["service"]}\n${m["area"]}\n${m["description"]}";b.setOnClickListener{AlertDialog.Builder(this).setTitle("قبول الطلب؟").setMessage("رقم العميل: ${m["phone"]}").setNegativeButton("إلغاء",null).setPositiveButton("قبول"){_,_->repo.acceptRequest(m["id"].toString()){ok,msg->Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}}.show()};list.addView(b)
        }},{e->Toast.makeText(this,e,Toast.LENGTH_SHORT).show()})
        r.addView(button("رجوع"){listener?.remove();showProviderHome()});setContentView(r)
    }
}
