# خدملك Khedmak v0.4 — Firebase Connected Edition

هذه النسخة تحتوي على ربط برمجي مع Firebase Authentication و Cloud Firestore و Storage libraries، وتدعم إنشاء حساب زبون/مقدم خدمة، تسجيل الدخول، إنشاء طلبات، حفظ الموقع عند السماح، واستقبال/قبول الطلبات لمقدم الخدمة.

## خطوة الربط المطلوبة قبل التشغيل
لا يمكن لأي مشروع Android الاتصال بقاعدة Firebase الخاصة بك بدون ملف إعداد المشروع `google-services.json` من حسابك في Firebase.

1. أنشئ مشروعًا في Firebase Console.
2. أضف Android app بالـ package name: `com.khedmak.app`
3. نزّل `google-services.json` وضعه داخل مجلد `app/`.
4. فعّل Authentication > Email/Password.
5. أنشئ Firestore Database.
6. (اختياري الآن) فعّل Storage.
7. افتح المشروع في Android Studio ثم Sync وRun.

## Collections المستخدمة
`users`: بيانات المستخدم والدور (`customer` أو `provider`).
`requests`: طلبات الخدمة وحالتها (`pending` / `accepted`) مع الموقع عند توفره.

## ملاحظات
هذه نسخة MVP حقيقية من ناحية طبقة الاتصال، لكنها لا تتضمن بعد نظام دفع، دردشة فورية، إشعارات FCM، لوحة تحكم ويب، أو نظام عمولة آمن على الخادم.
